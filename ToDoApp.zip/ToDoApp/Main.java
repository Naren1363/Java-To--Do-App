import java.util.Scanner;
@SuppressWarnings("resources")
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        TaskManager manager = new TaskManager();

        while (true) {
            System.out.println("\n1. Add Task\n2. Show Tasks\n3. Mark Task as Done\n4. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter task: ");
                    String desc = scanner.nextLine();
                    manager.addTask(desc);
                    break;
                case 2:
                    manager.showTasks();
                    break;
                case 3:
                    System.out.print("Enter task number to mark done: ");
                    int index = scanner.nextInt();
                    manager.markTaskDone(index);
                    break;
                case 4:
                    System.out.println("Bye!");
                    return;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
}
